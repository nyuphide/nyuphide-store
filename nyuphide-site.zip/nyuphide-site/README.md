# NYU PhiDE Merch Site — Setup

Everything here is free except the domain name.

```
index.html          the website (don't need to edit)
config.js           EDIT: prices, items, Zelle info, order days
images/             product photos and logo
apps-script/Code.gs paste into Google Apps Script (step 2)
```

---

## 1. Fill in config.js

Open `config.js` and set:
- `price` for each item (in dollars, e.g. `35`)
- `zelleName` and `zelleContact`
- `orderDays` and `calendarMonths`
- `sponsor` (or leave it `""`)

Delete any item you aren't selling. To add one, copy a block, give it a new `id`, and put its photo in `images/`.

## 2. Set up order emails (Google Sheet + Apps Script)

1. Go to sheets.google.com and create a blank sheet named **NYU PhiDE Orders**.
2. In the sheet: **Extensions → Apps Script**.
3. Delete what's there and paste in all of `apps-script/Code.gs`.
4. At the top, set `OWNER_EMAIL`, `ZELLE_NAME`, `ZELLE_CONTACT`, and the `PRICES` (same numbers and ids as `config.js`).
5. Click **Save**. In the function dropdown pick **testOrder** and click **Run**. Approve the permissions it asks for (it needs to edit the sheet and send email as you). You should get an email and see a row in an **Orders** tab.
6. Click **Deploy → New deployment**. Gear icon → **Web app**.
   - Execute as: **Me**
   - Who has access: **Anyone**
   - Click **Deploy**, then copy the **Web app URL** (ends in `/exec`).
7. Paste that URL into `config.js` as `orderScriptUrl`.

If you change Code.gs later: **Deploy → Manage deployments → Edit (pencil) → Version: New version → Deploy**. The URL stays the same.

## 3. Put the site on GitHub Pages

1. Make a free account at github.com.
2. Click **+ → New repository**. Name it `nyuphide-merch`, set it to **Public**, and create it.
3. Click **uploading an existing file**. Drag in `index.html`, `config.js`, and the `images` folder. (You don't need to upload `apps-script` or this README.) Click **Commit changes**.
4. Go to **Settings → Pages**. Under *Build and deployment*, Source: **Deploy from a branch**, Branch: **main**, folder **/ (root)**. Save.
5. After a minute your site is live at `https://YOUR-USERNAME.github.io/nyuphide-merch/`. Place a test order to make sure the email arrives.

To change prices later, open `config.js` on GitHub, click the pencil, edit, and commit. The site updates in about a minute.

## 4. Connect your own domain

1. Buy the domain (Cloudflare, Porkbun, Namecheap, etc.). If you have the GitHub Student Developer Pack, check it for a free first-year domain.
2. In GitHub: **Settings → Pages → Custom domain**, type it (e.g. `nyuphide.com`), Save.
3. At your registrar, add these DNS records:
   - Four **A** records for `@` pointing to:
     `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - One **CNAME** record for `www` pointing to `YOUR-USERNAME.github.io`
4. Wait for DNS (minutes to a few hours), then tick **Enforce HTTPS** in Settings → Pages.

## How orders work

1. Someone adds items, enters name + email, and clicks **Place order**.
2. The order is saved in your sheet, you get an email, and the buyer gets a receipt with Zelle instructions.
3. The site shows the total, your Zelle info, and an order number (like `PDE-7K3QX`) to put in the Zelle memo.
4. When the Zelle payment comes in, find that order number in the sheet and change **Paid?** to **Yes**.
5. On each order day, filter the sheet to Paid = Yes and send the sizes to your vendor.

Free limits: a regular Gmail account can send about 100 emails a day from Apps Script. Each order uses 2 (you + buyer). If you expect more than ~50 orders in one day, set `SEND_BUYER_CONFIRMATION = false`.
