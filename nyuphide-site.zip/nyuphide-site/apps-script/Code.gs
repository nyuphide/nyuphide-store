/**
 * NYU PhiDE Merch — order receiver
 * Paste this whole file into Extensions > Apps Script in your Google Sheet.
 * Every order from the website is saved as a row and emailed to you.
 */

// ===== EDIT THESE =====
const OWNER_EMAIL = 'you@example.com';      // where order emails go
const SEND_BUYER_CONFIRMATION = true;        // email the buyer a receipt with Zelle info
const ZELLE_NAME = '[ZELLE NAME]';
const ZELLE_CONTACT = '[ZELLE EMAIL OR PHONE]';

// Prices in dollars. Keep these the SAME as config.js on the website.
// The total is recalculated here so nobody can change prices in their browser.
const PRICES = {
  windbreaker: 0,
  hoodie: 0,
  polo: 0,
  shorts: 0,
  socks: 0,
};
const NAMES = {
  windbreaker: 'ΦΔΕ Windbreaker',
  hoodie: 'ΦΔΕ Hoodie',
  polo: 'Alumna Polo',
  shorts: 'ΦΔΕ Sweat Shorts',
  socks: 'ΦΔΕ Crew Socks',
};
// ======================

const SHEET_NAME = 'Orders';
const HEADERS = ['Timestamp', 'Order #', 'Name', 'Email', 'Items', 'Total ($)', 'Notes', 'Paid?'];

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const data = JSON.parse(e.postData.contents);

    const order = clean(data.order, 20);
    const name = clean(data.name, 80);
    const email = clean(data.email, 120);
    const notes = clean(data.notes, 300);
    if (!order || !name || !email || !Array.isArray(data.items) || data.items.length === 0) {
      return json({ ok: false, error: 'missing fields' });
    }

    let total = 0;
    const lines = [];
    data.items.slice(0, 50).forEach(function (it) {
      const id = String(it.id || '');
      if (!(id in PRICES)) return;                       // ignore unknown items
      const qty = Math.max(1, Math.min(20, parseInt(it.qty, 10) || 1));
      const size = clean(it.size, 12);
      total += qty * PRICES[id];
      lines.push(qty + ' × ' + NAMES[id] + ' (' + size + ')');
    });
    if (lines.length === 0) return json({ ok: false, error: 'no valid items' });

    const sheet = getSheet();
    sheet.appendRow([new Date(), order, name, email, lines.join('\n'), total, notes, 'No']);

    const itemsText = lines.join('\n');
    MailApp.sendEmail({
      to: OWNER_EMAIL,
      subject: 'New merch order ' + order + ' – ' + name + ' ($' + total.toFixed(2) + ')',
      body: 'Order: ' + order + '\nName: ' + name + '\nEmail: ' + email +
            '\nTotal: $' + total.toFixed(2) + '\n\nItems:\n' + itemsText +
            (notes ? '\n\nNotes: ' + notes : '') +
            '\n\nCheck your Zelle for a payment with memo ' + order + ', then mark "Paid?" as Yes in the sheet.',
    });

    if (SEND_BUYER_CONFIRMATION) {
      MailApp.sendEmail({
        to: email,
        subject: 'Your NYU PhiDE merch order ' + order,
        body: 'Hi ' + name + ',\n\nThanks for your order! Here is what you ordered:\n\n' + itemsText +
              '\n\nTotal: $' + total.toFixed(2) +
              '\n\nTo lock it in, send the total with Zelle to ' + ZELLE_CONTACT + ' (' + ZELLE_NAME + ')' +
              ' and put ' + order + ' in the memo.\n\nNYU PhiDE',
      });
    }

    return json({ ok: true });
  } catch (err) {
    return json({ ok: false, error: String(err) });
  } finally {
    lock.releaseLock();
  }
}

function getSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(HEADERS);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, HEADERS.length).setFontWeight('bold');
  }
  return sheet;
}

// Trim, cap length, and stop text from being read as a spreadsheet formula.
function clean(v, max) {
  let s = String(v == null ? '' : v).trim().slice(0, max);
  if (/^[=+\-@]/.test(s)) s = "'" + s;
  return s;
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

// Run this once from the editor to test: it adds a sample row and sends you an email.
function testOrder() {
  doPost({ postData: { contents: JSON.stringify({
    order: 'PDE-TEST1', name: 'Test Person', email: OWNER_EMAIL, notes: 'test',
    items: [{ id: 'socks', qty: 2, size: 'One size' }]
  }) } });
}
